import React, { Fragment } from "react";
import { useReducer } from "react";

import {add} from '@/Util'

export default function App() {
  const [counter, plus] = useReducer(c => c + 1, 0)
  return (
    <Fragment>
      <p>Hello, Fucking World!!</p>
      <p>1 + 1 = {add(1, 1)}</p>
      <button onClick={plus}>Counter: {counter}</button>
    </Fragment>
  )
}